package sensorGather;

import galgeleg.*;
import java.rmi.Naming;
import java.util.Scanner;

public class SensorGatherKlient {

    public static void main(String[] args) throws Exception {

        //boolean aktiv = true; // Boolean til at se om spillet skal spilles
        SensorGatherI g = (SensorGatherI) Naming.lookup("rmi://localhost:1099/SensorGatherService");

        g.getSensorData();
        int i = 0;
        for (Integer temp : g.getSensorData()) {
            System.out.println("Value at index: " + i + " is " + temp);
            i++;
        }
    }
}
