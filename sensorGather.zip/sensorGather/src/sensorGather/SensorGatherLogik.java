package sensorGather;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;


public class SensorGatherLogik {
  private ArrayList<Integer> sensorData = new ArrayList<>();
  private int dataAmount;
  private boolean dataIsStored;
  
  public int getDataAmount(ArrayList<Integer> sensorData){
      dataAmount = sensorData.size();
      return dataAmount;
  }
  
  /*
  public boolean storeData(ArrayList<Integer> sensorData) {  
  
  }
  
  */
  
  public void storeData(Integer x) {
      sensorData.add(x);
      dataAmount++;
  }
  
  public boolean isDataStored(){
      return dataIsStored;
  }
  
  public ArrayList<Integer> getSensorData() {
      return sensorData;
  }

  public static String hentUrl(String url) throws IOException {
    BufferedReader br = new BufferedReader(new InputStreamReader(new URL(url).openStream()));
    StringBuilder sb = new StringBuilder();
    String linje = br.readLine();
    while (linje != null) {
      sb.append(linje + "\n");
      linje = br.readLine();
    }
    return sb.toString();
  }
}